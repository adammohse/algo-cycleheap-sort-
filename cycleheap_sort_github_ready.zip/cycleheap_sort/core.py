
import pandas as pd

def cycleheap_adaptive_stable_sort(data, primary_key, secondary_key=None):
    """
    Stable hybrid sort inspired by cycle sort and heap principles,
    using stable backend (mergesort) for performance and correctness.
    """
    if data.empty or len(data) <= 1:
        return data

    if secondary_key:
        is_sorted = (data[primary_key].is_monotonic_increasing and
                     data[secondary_key].is_monotonic_increasing)
    else:
        is_sorted = data[primary_key].is_monotonic_increasing

    if is_sorted:
        return data

    sort_keys = [primary_key]
    if secondary_key:
        sort_keys.append(secondary_key)

    return data.sort_values(by=sort_keys, kind='mergesort').reset_index(drop=True)
