
from setuptools import setup, find_packages

setup(
    name='cycleheap_sort',
    version='0.1.0',
    description='A stable hybrid sorting algorithm combining cycle, heap, and mergesort principles',
    author='Adnan Mohsen & ChatGPT',
    author_email='adnan@example.com',
    packages=find_packages(),
    install_requires=['pandas'],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.7',
)
